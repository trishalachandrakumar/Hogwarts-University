function My_function() {
    alert("Successfully submitted!");
}

// Get form values
var name = document.getElementById("name").value;
var email = document.getElementById("email").value;
var password = document.getElementById("password").value;

// Create an object to hold the form data
var formData = {
    name: name,
    email: email,
    password: password
};





// Send a POST request to the server with the form data
fetch("/signup", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
    })
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {
        document.getElementById("message").textContent = data.message;
    })
    .catch(function (error) {
        console.error("Error:", error);
    });